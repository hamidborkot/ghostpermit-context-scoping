# GhostPermit

Code, data, and paper artefacts for the **GhostPermit** study of joint-use
authorization for personal AI assistants that connect to multiple user data
sources (calendar, contacts, location, notes, email).

The repository ships the complete experimental harness (notebook 5, 71
cells), the consolidated results CSV (5 974 rows), **31 small per-test CSVs**
(one per experiment arm / attack variant), the offline statistical
reanalysis, the human-validation harness, the LaTeX manuscript, and the
reanalysis script that recomputes every reported number from the saved
cell counts.

> **Status.** Experimental code is research-grade. It was developed on
> Kaggle (GPU T4 x2) and re-run there; it has not been packaged as a
> PyPI library. The retained CSVs are the *authoritative* results; the
> Python files are the exact code that produced them, kept verbatim so a
> reviewer can replay any cell.

---

## What is in this repo

| Path | What |
|---|---|
| `notebooks/ghost_permit.ipynb` | The canonical notebook (v5, 71 cells). Covers the full v5 engine: setup → records/attacks → engine → PASS 1 (3 small models) → gates → PASS 2 (14B + 8B) → PASS 3 (deepen) → final report. |
| `notebooks/archive/` | Earlier notebook versions (v4 = 63 cells, v2 = 39 cells). |
| `src/` | One `.py` file per notebook cell (`c00_…` through `c70_…`), with a header that explains which cell it came from and what it does. |
| `data/raw/results.csv` | The **master** consolidated results CSV (5 974 rows, 30 columns). Covers all 5 stages (A1, A2, A3, B, R), all 7 arms (combo, def, full, pidet, sand, scoped, spot), 4 models, 2 tiers. |
| `data/raw/final_report.txt` | The final 9-section report produced by the last notebook cell. |
| `data/tests/` | **31 small CSVs**, one per individual test (split from the master). See `data/tests/README.md` for the naming convention and row counts. |
| `data/processed/` | The older v2/v4 result CSVs (`precision_trials.csv`, `final_trials.csv`, `scoped_trials.csv`, `widen_trials.csv`, `precision_trials_corrected.csv`, `precision_summary.csv`, `manual_check.csv`) plus `precision_table.tex`. |
| `data/cell_counts/ghostpermit_cell_counts.csv` | The aggregate positive/valid cell-count ledger used by the paper's statistical reanalysis. |
| `data/labels/` | Reserved for the human-validation label files. Empty by default. |
| `results/figures/fig_precision.pdf` | Stacked-bar figure: deny / review-high / review-low share per model × task class. |
| `results/tables/precision_table.tex` | LaTeX table with Wilson 95% intervals. |
| `paper/` | The Elsevier CAS manuscript: `GhostPermit_JointUse_CEE.tex`, the assembly note, the structural source-checks JSON, the offline `ghostpermit_reanalysis.py` script and its results JSON. |
| `docs/EXPERIMENTS.md` | One-paragraph description of every experiment. |
| `docs/REPRODUCING.md` | How to re-run the smoke tests, the full campaigns, and the analysis cells. |
| `requirements.txt` | Python dependencies. |
| `CITATION.bib`, `CITATION.cff` | Citation files (placeholder). |

---

## Quick start

```bash
# 1. Clone
git clone https://github.com/<you>/ghostpermit.git
cd ghostpermit

# 2. Install dependencies (CPU analysis only)
pip install -r requirements.txt

# 3. Read the final report
cat data/raw/final_report.txt

# 4. Inspect one small per-test CSV
python -c "import pandas as pd; print(pd.read_csv('data/tests/B_base_arm_scoped.csv').head())"

# 5. Replay the offline statistical reanalysis that every paper number comes from
python paper/ghostpermit_reanalysis.py
```

---

## The v5 experiments at a glance

| Stage | Name | What it tests | Models | Rows |
|---|---|---|---|---:|
| **B** | Baseline | Multiple defenses (combo, def, full, pidet, sand, scoped, spot) on fixed records with injected notes (phrasings A + B). | 3 small + 14B | 3 072 |
| **A1** | Adaptive attack 1 | Best-of-K injected notes — the attacker tries 16 note variants and keeps the best one. | 3 small (+ 14B deep) | 1 610 |
| **A2** | Adaptive attack 2 | Iterative attacker — after a failed round the attacker sees the defense text + the answer and writes a new note. | 3 small | 366 |
| **A3** | Detector-evasion | The injected note forbids exact quoting (paraphrase / spelled digits) to target the observable lower bound. | 3 small | 288 |
| **R** | Randomized records | Randomized, longer, noisier records (new identifiers per trial, mixed formats). | 3 small | 648 |
| | | | **Total** | **5 974** |

---

## Headline numbers (from `data/raw/final_report.txt`)

| Quantity | Value | Source |
|---|---:|---|
| Total rows | 5 974 | `data/raw/results.csv` |
| Models | 4 (Phi-3.5-mini, Qwen3-4B, Granite-3.3-2B, Qwen2.5-14B) | same |
| Wall-clock | 10.55 h | `final_report.txt` |
| Scoped arm forbidden joins (ALL attacks) | 0 / 1 269 (0.00%, Wilson UB 0.30%) | §9 Verdict |
| Full arm under adaptive attacks | 151 / 384 (39.3%) | §9 |
| Def arm under adaptive attacks | 164 / 511 (32.1%) | §9 |
| Combo arm under adaptive attacks | 93 / 522 (17.8%) | §9 |
| Scoped vs full (paired McNemar) | p = 4.4 × 10⁻⁴⁷ | §2 |
| Scoped vs def (paired McNemar) | p = 5.7 × 10⁻⁴² | §2 |
| Forbidden joins among ALLOWed (scoped) | 0 / 1 269 | §8 |

---

## Citing

See `CITATION.bib` and `CITATION.cff`. Both are placeholders: fill in
the final DOI / venue when the paper is accepted.

## License

MIT — see `LICENSE`. The paper LaTeX in `paper/` follows the Elsevier CAS
template; the CAS class bundle is **not** redistributed here.

## Ethics & responsible disclosure

The synthetic records are entirely fictitious. No real user data was used.
The attack prompts study model behaviour under *simulated* malicious tool
outputs; they do not exploit any specific production system.
