# Notebooks

## ghost_permit.ipynb

The canonical notebook. 63 code cells. This is the exact notebook that
was run on Kaggle (GPU T4 x2, Internet ON) to produce every CSV in
`data/processed/` and `data/cell_counts/`.

Run order is top-to-bottom. Each cell that writes a CSV opens it in
append mode and writes the header only if the file does not exist, so
the notebook is resumable: if Kaggle disconnects you, re-run the same
cell to continue from where you left off.

The same cells are also extracted as standalone `.py` files in
`../src/c00_…` through `../src/c62_…`. The two views are kept in sync
by the build script at `../../scripts/build_repo.py` (not in the repo
by default; rerun it if you edit the notebook and want to refresh
`src/`).

## archive/

- `ghost_permit_v2.ipynb` — an earlier 39-cell version. Kept for
  history; not the canonical source. Do not run it for new experiments;
  use `ghost_permit.ipynb` instead.
