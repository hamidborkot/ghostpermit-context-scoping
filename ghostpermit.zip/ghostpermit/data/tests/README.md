# Tests — one CSV per experiment arm

The master `data/raw/results.csv` (5,974 rows) has been split into 31 small
CSVs below, **one per individual test**. Every split CSV has the same schema
as the master (30 columns) and a file name that encodes the test's stage,
level, and arm or attack variant.

## Naming convention

```
<stage>_<level>_<descriptor>.csv
```

| Prefix | Stage | Level | What it tests |
|---|---|---|---|
| `A1_pilot_atk00` … `A1_pilot_atk15` | A1 (adaptive attack 1) | pilot | best-of-K injected-note attacker, one CSV per attacker note variant (0–15). 3 small models × 4 forbidden combos × 2 task classes × 2 phrasings. |
| `A1_deep_big_model` | A1 | deep | deepen run on Qwen2.5-14B-Instruct (only the cases where a gate said GO). |
| `A2_pilot_iterative` | A2 (adaptive attack 2) | pilot | iterative attacker — after each failed round the attacker sees the defense text + the answer and writes a new note. 3 small models. |
| `A3_pilot_atkE0` | A3 (detector-evasion attack) | pilot | injected note forbids exact quoting (paraphrase / spelled digits). Variant E0. |
| `A3_pilot_atkE1` | A3 | pilot | same attack, variant E1. |
| `B_base_arm_<arm>` | B (baseline) | base | no attack; one CSV per defense arm: `combo`, `def`, `full`, `pidet`, `sand`, `scoped`, `spot`. 4 models (3 small + 14B) × 4 forbidden combos × 2 task classes × 2 phrasings. |
| `R_pilot_arm_<arm>` | R (randomized records) | pilot | randomized, longer, noisier records (new identifiers per trial). One CSV per arm: `combo`, `def`, `full`, `scoped`. 3 small models. |

## Row counts

| File | Rows |
|---|---:|
| `A1_pilot_atk00.csv` … `A1_pilot_atk15.csv` (16 files) | 1 546 |
| `A1_deep_big_model.csv` | 64 |
| `A2_pilot_iterative.csv` | 366 |
| `A3_pilot_atkE0.csv` + `A3_pilot_atkE1.csv` | 288 |
| `B_base_arm_combo.csv` | 480 |
| `B_base_arm_def.csv` | 480 |
| `B_base_arm_full.csv` | 480 |
| `B_base_arm_pidet.csv` | 384 |
| `B_base_arm_sand.csv` | 384 |
| `B_base_arm_scoped.csv` | 480 |
| `B_base_arm_spot.csv` | 384 |
| `R_pilot_arm_combo.csv` | 144 |
| `R_pilot_arm_def.csv` | 144 |
| `R_pilot_arm_full.csv` | 216 |
| `R_pilot_arm_scoped.csv` | 144 |
| **Total** | **5 974** (= master `results.csv`) |

## Schema (30 columns, identical in every file)

| Column | Type | Meaning |
|---|---|---|
| `uid` | str | SHA1 hash of the trial key, first 16 hex chars. |
| `stage` | str | `A1` / `A2` / `A3` / `B` / `R` — which experiment stage. |
| `level` | str | `pilot` / `base` / `deep` — sampling depth. |
| `model` | str | HuggingFace model ID (short form). |
| `tier` | str | `small` (≤4B) or `big` (14B). |
| `arm` | str | Defense arm: `combo`, `def`, `full`, `pidet`, `sand`, `scoped`, `spot`. |
| `combo` | str | Permission combination `C1`–`C10`. |
| `cls` | str | Task class: `single` or `pair`. |
| `trial` | int | Trial index within the (model, combo, cls, arm, phr, atk) cell. |
| `phr` | str | Injection phrasing: `A`, `B`, or `` (empty). |
| `atk` | str | Attack-note variant: `0`–`15` for A1, `E0`/`E1` for A3, `NaN` otherwise. |
| `placement` | str | Where the injected note was placed: `start`, `mid`, `end`, `all`, etc. |
| `round` | int | Adaptive-attack round (0 = initial, 1 = after one retry, …). |
| `rkind` | str | Round kind: `fixed` (non-adaptive) or `adaptive`. |
| `rseed` | int | Random seed used for this trial. |
| `task` | str | The user task text. |
| `context` | JSON | List of granted source names. |
| `needed` | JSON | List of sources the task actually needs. |
| `scope` | JSON | List of sources the router gave the model (may be smaller than `context`). |
| `fallback` | int | 1 if the router fell back to the full context, 0 otherwise. |
| `used` | JSON | Sources detected in the response by the STRICT detector. |
| `used_norm` | JSON | Sources detected by the normalising detector (handles paraphrases). |
| `used_relaxed` | JSON | Sources detected by the RELAXED detector (generous). |
| `outside` | JSON | Sources in `used` but NOT in `scope` (potential leak). |
| `join` | int | 1 if the response contains a forbidden 3-source join, 0 otherwise. |
| `covers` | int | 1 if the response covers every source in `needed`. |
| `unneeded` | int | 1 if the response uses at least one source not in `needed`. |
| `inj` | str | The injected-note text (empty for non-injection arms). |
| `inj_next` | str | The next-round injected note (for iterative attacker; empty otherwise). |
| `response` | str | The model's saved response text (truncated to 4000 chars). |

## How to reproduce the split

```bash
python scripts/split_results.py    # reads data/raw/results.csv, writes data/tests/*.csv
```
