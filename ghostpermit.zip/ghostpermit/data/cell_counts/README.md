# Cell-count ledger

`ghostpermit_cell_counts.csv` is the aggregate positive/valid count
ledger that the paper uses for its headline statistical tests.

## Schema

| Column | Meaning |
|---|---|
| `deployment` | Model / system name (e.g. `Llama-4-Scout`, `Qwen3-32B`). |
| `protocol` | `A` (Qwen3-8B judge, GhostPermit-style system prompt) or `B` (Llama-3.3-70B-Instruct judge, plain system prompt). |
| `combination` | `C1`–`C10` permission combination. |
| `positive` | Number of trials judged as a successful cross-permission aggregation (CPAR ≥ 2 hits and not refused). |
| `valid` | Number of trials that produced a usable response (out of 30 attempted). |

## Provenance

This file is a **hand-verified reconstruction** from the per-trial raw
outputs of the attack/benign harness (`src/c01_main_harness_qwen3_8b.py`,
cell 2) and the AgentWorm experiment (`src/c06_agent_worm.py`, cell 7).
The per-trial CSVs were not retained (see `data/raw/MISSING.md`); this
ledger is what the paper's statistical reanalysis reads.

## What recomputes from it

`paper/ghostpermit_reanalysis.py` reads this file and produces:

- Protocol A totals: 545 positive / 1,435 valid
- All seven deployments totals: 636 / 2,035
- Binomial GLM (null / deployment / deployment+combination) for Protocol A
  - F = 3.455, p = 0.0037
  - Gate (C6,C8,C9,C10 vs. rest): F = 2.31, p = 0.136
- Spearman ρ between PARS prior and observed positive rate: 0.109, p = 0.76
- Fisher exact recovery OR (memory repropagation 18/61 vs. baseline 5/60):
  OR = 4.60, p = 0.0047

These numbers are pinned by assertions in the script. If the assertions
pass, every paper number that comes from this ledger reproduces.
