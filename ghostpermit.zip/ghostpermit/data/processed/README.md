# Processed experimental CSVs

Every file in this folder is the retained output of a specific notebook
cell. The cells are kept verbatim in `src/`; the schema below is for
quick reference.

## precision_trials.csv

- **Producer:** `src/c10_label_precision_full.py` (cell 11)
- **Rows:** 1,350 (10 combos × 3 classes × 15 trials × 3 models)
- **Columns:**
  - `uid` — SHA1 of `f"{model}|{combo}|{cls}|{trial}"`, first 16 hex chars
  - `model` — HuggingFace model ID
  - `combo` — `C1`–`C10` (permission combination)
  - `cls` — `single`, `pair`, `brief`
  - `trial` — 0..14
  - `context, needed, strict_set, relaxed_set` — JSON-encoded lists of source names (`calendar`, `contacts`, `location`, `notes`, `email`)
  - `n_strict, n_relaxed` — number of sources detected by STRICT / RELAXED
  - `strict_hits` — JSON dict `{source: count}` of STRICT marker hits
  - `refused` — 0/1
  - `resp_chars` — length of saved response text
  - `response` — saved response text (truncated to 4000 chars by the harness)

## precision_trials_corrected.csv

- **Producer:** `src/c14_corrected_detectors.py` (cell 15)
- **Rows:** 1,350 (same trials as `precision_trials.csv`)
- **Adds / replaces:** `short` (model short name), `s2` (corrected strict
  set), `r2` (corrected relaxed set), `union_deny`, `js` (strict join),
  `jr` (relaxed join), `cat` (`deny` / `review_high` / `review_low` / `n/a`),
  `creep`
- **Removes:** `context`, `needed` (still in the source CSV but dropped
  from the corrected export to keep file size down)

## precision_summary.csv

- **Producer:** `src/c11_label_precision_analysis_full.py` (cell 12)
- **Rows:** 12 (3 models + ALL MODELS, × 3 classes)
- **Columns:** `model, cls, n_union_deny, interval_deny, review_high,
  review_low, review_low_pct, review_low_ci, join_strict, join_relaxed`

## final_trials.csv

- **Producer:** `src/c21_final_experiment_full.py` (cell 22)
- **Rows:** 2,304 (4 combos × 2 classes × 8 trials × 7 conditions × 3 models)
- **Columns:** `uid, model, combo, cls, trial, cond, phr, wording, task,
  context, needed, scope, fallback, used, outside_scope, covers_needed,
  answered, response`
- **`cond` values:** `full_inj` (injected instruction, 2 phrasings A/B),
  `full_uw` (user widening, no injection), `router_inj`, `router_uw`,
  `router_plain` (scoped, no injection)

## scoped_trials.csv

- **Producer:** `src/c15_scoped_context_experiment.py` (cell 16)
- **Rows:** 1,800 (10 combos × 2 classes × 10 trials × 3 conditions × 3 models)
- **Columns:** `uid, model, combo, cls, trial, wording, cond, task,
  context, needed, scope, fallback, used, outside_scope, covers_needed,
  response`
- **`cond` values:** `oracle` (needed sources only), `router` (LLM router)

## widen_trials.csv

- **Producer:** `src/c18_scope_widening_test.py` (cell 19)
- **Rows:** 480 (4 combos × 2 classes × 10 trials × 2 conditions × 3 models)
- **Columns:** `uid, model, combo, cls, trial, cond, needed, scope, used,
  join_used, creep, covers_needed, response`
- **`cond` values:** `full_widen` (whole context), `scoped_widen`
  (router-mediated)

## manual_check.csv

- **Producer:** `src/c09_manual_check_export.py` (cell 10)
- **Rows:** ~6 (one per `cls` group, sample size capped at 20 per group;
  the smoke run produced 6 rows because only one model had been run)
- **Columns:** `uid, model, cls, context, strict_set, relaxed_set,
  response, true_sources`
- **Note:** `true_sources` is left blank for the human annotator to fill
  in. The full 30-item version is in cell 13 (`c12_manual_check_30_items.py`).

## precision_table.tex

- **Producer:** `src/c11_label_precision_analysis_full.py` (cell 12)
- **Content:** LaTeX `table` environment with one row per
  (model, cls); columns: Union denies, Deny, Review high, Review low,
  95% Wilson interval. A copy is also in `results/tables/`.
