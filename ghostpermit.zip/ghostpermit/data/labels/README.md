# Human validation labels

This folder is empty by default. It receives its contents only when a
human annotator runs the validation script
(`src/c29_validation_60_v2.py`, notebook cell 30) on the retained
`final_trials.csv` (5-model confirmation run, which itself lives in
`data/raw/` — see `data/raw/MISSING.md`).

## What the validation script writes here

After running `python src/c29_validation_60_v2.py` with `ACTION =
"annotate_A"`, the following files appear in this folder:

- `sample_private.json` — the fixed 60-item stratified sample
  (5 models × 3 arms × 2 task classes × 2 injection phrasings, 1 of 32
  candidates per stratum). Includes a SHA-256 of each sampled response
  so labels cannot be silently re-applied to a different response.
- `sampling_manifest.json` — provenance: seed, strata definition,
  source file, source SHA-256.
- `labels_A.json` — annotator A's labels, keyed by item id.
- `labels_B.json` — annotator B's labels (optional, must be a different
  person).
- `labels_consensus.json` — adjudicated consensus labels.
- `agreement.json` — A/B agreement counts.
- `detector_validation_A.json`, `detector_validation_consensus.json` —
  final scoring (precision, recall, F1, Wilson CIs) of the STRICT
  detector against the human labels.
- `validation_cases_A.json` — per-item case dump.
- `source_decisions_A.csv` — long-form CSV of (item, source,
  human_present, detected).
- `assisted_content_review_<timestamp>.json` — provenance log if
  assistant-suggested label corrections were applied.
- `outside_scope_inspection.json` — manual inspection of the 2–3
  out-of-scope marker matches.

## How to run the validation

See `docs/REPRODUCING.md` section 3 and the long docstring at the top
of `src/c29_validation_60_v2.py`.

## Why these files are not committed

They contain a human's judgement of model-generated text. They should
be committed only after the annotation is complete and the paper's
disclosure of the annotation protocol is finalized.

## Pilot files

An earlier 9-item pilot (`human_sample.csv`, `human_labels.csv`) was
produced by an older version of the validation cell
(`src/c25_human_validation_interactive.py`, cell 26). That pilot is
**not** imported into the 60-item validation; the production script
explicitly refuses to import pilot labels.
