# Raw model outputs

## results.csv (master)

The **master consolidated results CSV** produced by notebook 5 (v5 engine).
5 974 rows, 30 columns. Covers all 5 stages, all 7 arms, 4 models, 2 tiers.

See `data/tests/README.md` for the column schema and the 31-file split.

## final_report.txt

The 9-section final report printed by the last cell of notebook 5.
Contains the inventory, baselines, paired tests, adaptive attack 1
(best-of-K), adaptive attack 2 (iterative), detector-evasion attack,
randomized records, larger models, monitor decisions, and the verdict.

## Older raw CSVs (not retained)

The following CSVs were produced by earlier notebook versions (v2/v4)
but were superseded by the v5 `results.csv`. They are documented in
`data/raw/MISSING.md` (historical).

| Missing file | Producer cell (v4) | Notes |
|---|---|---|
| `raw_trials.csv` | `c01_main_harness_qwen3_8b.py` | Qwen3-8B attack/benign. Superseded by v5 stage B. |
| `utility_trials.csv` | `c02_utility_baseline.py` | Baseline vs post-injection. Superseded by v5 stage B. |
| `agentworm_trials.csv` | `c06_agent_worm.py` | 3-hop propagation. Not in v5. |
| `confirm_trials.csv` | `c26_confirmation_run_full.py` | 5-model confirmation (3 520 rows). Superseded by v5. |
| `defense_larger_trials.csv` | `c47_defense_larger_full.py` | Defense on 7B/8B. Superseded by v5 PASS 2. |
| `scoped_larger_trials.csv` | `c54_scoped_larger_variant.py` | Scoped on 7B/8B. Superseded by v5 PASS 2. |
