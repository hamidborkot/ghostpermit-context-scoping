# Paper artefacts

This folder contains the Elsevier CAS manuscript for the GhostPermit
paper, plus the offline reanalysis script and its results.

## Files

| File | What |
|---|---|
| `GhostPermit_JointUse_CEE.tex` | Main manuscript. 8 sections, 8 tables, 2 algorithms, 4 figure environments. Self-contained except for the CAS class bundle and `cas-refs.bib`. |
| `GhostPermit_Assembly_Note.md` | Editorial assembly note: which sections go where, what the author must fill in (metadata, CRediT, funding, AI-use disclosure), what was already checked. |
| `GhostPermit_Source_Checks.json` | Structural check results: 8 sections, 8 tables, 2 algorithms, 4 figures, no undefined internal references, no duplicate labels, brace balance OK. |
| `ghostpermit_reanalysis.py` | Offline statistical reanalysis script. Reads `../data/cell_counts/ghostpermit_cell_counts.csv`, fits GLMs, runs gate test, Spearman, Fisher. Writes `ghostpermit_reanalysis_results.json`. |
| `ghostpermit_reanalysis_results.json` | The output of running the reanalysis script. |
| `ghostpermit_cell_counts.csv` | The aggregate cell-count ledger (also symlinked/copied into `../data/cell_counts/`). |

## Compiling the manuscript

The manuscript uses the Elsevier CAS class (`cas-sc.cls`,
`cas-model2-names.bst`), which is **not** redistributed here. Compile
on Overleaf:

1. Create a new project from the Elsevier CAS template.
2. Upload `GhostPermit_JointUse_CEE.tex` as the main document.
3. Upload your verified `cas-refs.bib`.
4. Upload the figure PDFs (`fig1_concept.pdf`, `fig2_combination_profile.pdf`,
   `fig3_pars.pdf`, `fig4_propagation.pdf`) into `figures/` (or `figs/`).
5. Recompile from scratch.

## What still needs to be filled in

Author metadata, CRediT, competing-interests, funding, repository
identifier, and AI-use disclosure are all left as commented fields in
the `.tex`. See `GhostPermit_Assembly_Note.md` section "Final
author-controlled entries".

## Running the reanalysis

```bash
cd <repo root>
python paper/ghostpermit_reanalysis.py
```

The script pins the headline values with assertions; if it exits 0, the
paper's statistical numbers reproduce.
