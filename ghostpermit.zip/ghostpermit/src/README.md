# Source modules

Every `.py` file in this folder is a **faithful, verbatim copy** of one
code cell from `../notebooks/ghost_permit.ipynb` (v5), with a small
header comment prepended that records:

- which notebook cell it came from,
- what experiment it runs,
- which CSV (if any) it writes.

The files are numbered `c00_…` through `c70_…` to match the notebook
cell order, so reading them in alphabetical order reproduces the
notebook's run order.

## v5 engine cells (63–70)

Cells 63–70 are the **new v5 engine** that replaces the older per-experiment
cells from notebook 4. They produce the consolidated `data/raw/results.csv`
(5 974 rows) and `data/raw/final_report.txt`.

| Cell | File | Purpose |
|---|---|---|
| 63 | `c62_v5_setup.py` | Setup, config, GPU check, LITE/FULL mode. |
| 64 | `c63_v5_records_attacks.py` | All records, detectors, 16 attack notes, 7 defense prompts. |
| 65 | `c64_v5_engine.py` | Model loading, generation, scoring, resume, `run_pass()`. |
| 66 | `c65_v5_pass1_small.py` | PASS 1: 3 small models, all 5 stages at pilot size. |
| 67 | `c66_v5_gates.py` | Statistical gates (McNemar) → decide deepen. |
| 68 | `c67_v5_pass2_big.py` | PASS 2: Qwen2.5-14B (4-bit) + 8B. |
| 69 | `c68_v5_pass3_deepen.py` | PASS 3: deepen small-model runs if gates said GO. |
| 70 | `c69_v5_final_report.py` | Final 9-section report → `final_report.txt`. |

## Older cells (1–62)

Cells 1–62 are from the earlier notebook versions (v2/v4) and are kept
for backwards compatibility. They produce the CSVs in `data/processed/`.
