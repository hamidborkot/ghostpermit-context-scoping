# Results

Figures and tables produced by the analysis cells. These are the
artefacts that the paper actually cites.

## figures/

- `fig_precision.pdf` — Stacked bar chart: share of outputs a union
  label would deny, broken into DENY (forbidden 3-source join found by
  STRICT detector), REVIEW HIGH (only RELAXED finds it), REVIEW LOW
  (neither finds it). One bar per (model, cls). Producer:
  `src/c11_label_precision_analysis_full.py` (last block).

## tables/

- `precision_table.tex` — LaTeX table with one row per (model, cls);
  columns: Union denies, Deny, Review high, Review low, 95% Wilson
  interval. Producer: `src/c11_label_precision_analysis_full.py`.
  A copy is also in `data/processed/` for convenience.

## What is NOT here

The four paper figures (`fig1_concept.pdf`, `fig2_combination_profile.pdf`,
`fig3_pars.pdf`, `fig4_propagation.pdf`) are produced by
`src/c57_fig1_concept.py`, `src/c58_fig2_combination_profile.py`, and
`src/c59_fig3_fig4.py` but were not exported from the Kaggle session.
Re-run those cells to regenerate them; see `docs/REPRODUCING.md` §4.
